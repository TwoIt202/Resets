# Manager file of script __main.py


managers = {
      # Requests
      "url": None,
      "sentences": 2,

      # Translate
      "from": None,
      "to": None,
}