#< % Managers of resets % >#


#< % Classes % >#
class WikipediaManager:
      
      managersW = {
            "lang": "en",
            "sentences": 1,
      }


class TranslatorManager:

      f = ''
      t = ''

      managersT = {
            "from": f,
            "to": t,
      }


class RequestsManager:

      managersR = {
            "type": "question_raw",
            "url": "https://7008.deeppavlov.ai/model",
            "arg_o": 0,
            "arg_t": 0,
      }