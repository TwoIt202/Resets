#< % Resets moduel example code in Python % >#

#< % Imports % >#
#< % Modules % >#
import wikipedia as w
import requests as r
from translate import Translator as t
from colorama import Fore, Back, Style
from termcolor import colored

#< % Manager % >#
import __manager__ as m
from __manager__ import WikipediaManager as mw
from __manager__ import TranslatorManager as mt
from __manager__ import RequestsManager as mr



class FilesIn:

      __manager__ = """#< % Managers of resets % >#


#< % Classes % >#
class WikipediaManager:
      
      managersW = {
            "lang": "en",
            "sentences": 1,
      }


class TranslatorManager:

      f = ''
      t = ''

      managersT = {
            "from": f,
            "to": t,
      }


class RequestsManager:

      managersR = {
            "type": "question_raw",
            "url": "https://7008.deeppavlov.ai/model",
            "arg_o": 0,
            "arg_t": 0,
      }      
      """









#< % Classes % >#
class WikipediaSearch:


      #< % Language % >#
      w.set_lang(mw.managers["lang"])



      #< % Function SEARCH % >#
      def search(page):


            #< % Variables % >#
            in_chat = w.summary(page, sentences=mw.managersW['sentences'])
            in_file = w.summary(page)

            return page


class TranslateWords:

      #< % Function TRANSLATE % >#
      def translate_w(text, fr, to):


            #< % Variables % >#
            mt.managersT['from'] = fr
            mt.managersT['to'] = to

            translator = t(from_lang=mt.managersT['from'], to_lang=mt.managersT['to'])
            translation = translator.translate(str(text))

            
            return translation


class AskQuestion:

      #< % Function ASK % >#
      def ask(askin):


            #< % Variables % >#
            data = {mr.managersR['type']: [askin]}
            res = r.get(mr.managersR['url'], json=data).json()
            santiment = res[mr.managersR['arg_o']][mr.managersR['arg_t']]

            
            return santiment


def pymd(name, txt):
      with open(name, 'w+', encoding='UTF-8') as w:
            w.write(txt)
            w.close()
      print(colored(f"Created file {name}", "yellow"))



pymd("__manager__.py", FilesIn.__manager__)
