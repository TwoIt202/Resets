"""
:authors: two-it2022
:license: Apache License, Version 1.2, see LICENSE file

:copyright: (c) 2022 two-it2022
"""

from .wiki import *
from .trans import *

__author__ = 'two-it2022'
__version__ = '0.0.3'
__email__ = 'kodland.group@gmail.com'
